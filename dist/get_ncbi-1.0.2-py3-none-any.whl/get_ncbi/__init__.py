from .main import main

# -*- coding: utf-8 -*-
"""
get_ncbi: Python script to automatically download representative species informations from NCBI genome

"""
__title__ = "get_ncbi"
__author__ = "msjeon27"
__license__ = "MIT License"
__copyright__ = "Copyright 2022 msjeon27"